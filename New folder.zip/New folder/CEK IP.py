import json
import os
import socket
import time
import threading
import urllib.request
import urllib.error
from datetime import datetime

# ─── KONFIGURASI ────────────────────────────────────────────────
RDP_ID       = "8RDP33"
SUPABASE_URL = "https://gomhpzvxabknayingzpw.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImdvbWhwenZ4YWJrbmF5aW5nenB3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzk1MDMyODUsImV4cCI6MjA5NTA3OTI4NX0.SFn0W53D9qFUXspNiw4MkLGXscPM1ELPjo7H1rGyx_0"
TABLE_NAME   = "rdp_ips"
# ────────────────────────────────────────────────────────────────

HEADERS = {
    "Content-Type" : "application/json",
    "apikey"       : SUPABASE_KEY,
    "Authorization": f"Bearer {SUPABASE_KEY}",
    "Prefer"       : "resolution=merge-duplicates",
}

def api_request(method, endpoint, data=None):
    url  = f"{SUPABASE_URL}/rest/v1/{endpoint}"
    body = json.dumps(data).encode() if data else None
    req  = urllib.request.Request(url, data=body, headers=HEADERS, method=method)
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            raw = r.read().decode()
            return json.loads(raw) if raw.strip() else []
    except urllib.error.HTTPError as e:
        print(f"Error {e.code}: {e.read().decode()}")
        return None
    except Exception as e:
        print(f"Error: {e}")
        return None

def get_public_ip():
    for url in ["https://api.ipify.org", "https://ifconfig.me/ip", "https://icanhazip.com"]:
        try:
            with urllib.request.urlopen(url, timeout=5) as r:
                ip = r.read().decode().strip()
                if ip:
                    return ip
        except Exception:
            continue
    return None

def main():
    public_ip = get_public_ip()

    if not public_ip:
        print("Gagal ambil IP. Cek koneksi VPN.")
        return

    api_request("POST", TABLE_NAME, {
        "rdp_id"      : RDP_ID,
        "public_ip"   : public_ip,
        "local_ip"    : "",
        "hostname"    : socket.gethostname(),
        "last_updated": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
    })

    all_data   = api_request("GET", f"{TABLE_NAME}?select=*") or []
    conflicts  = [r["rdp_id"] for r in all_data if r["rdp_id"] != RDP_ID and r.get("public_ip") == public_ip]

    print(f"\n  RDP : {RDP_ID}")
    print(f"  IP  : {public_ip}")

    if conflicts:
        print(f"  !! DUPLIKAT — IP ini juga dipakai oleh: {', '.join(conflicts)}")
        print(f"  Segera ganti VPN!")
    else:
        print(f"  OK  — Tidak ada konflik.")

    print()

REFRESH_SECS = 5 * 60  # 5 menit

def countdown(seconds):
    for remaining in range(seconds, 0, -1):
        mins, secs = divmod(remaining, 60)
        print(f"\r  Refresh otomatis dalam {mins:02d}:{secs:02d} — atau tekan Enter untuk cek sekarang...", end="", flush=True)
        time.sleep(1)
    print()

if __name__ == "__main__":
    # Flag untuk trigger refresh manual dari input Enter
    manual = threading.Event()

    def wait_enter():
        while True:
            input()
            manual.set()

    t = threading.Thread(target=wait_enter, daemon=True)
    t.start()

    try:
        while True:
            os.system("cls" if os.name == "nt" else "clear")
            main()
            manual.clear()
            print("  Tekan Enter untuk cek sekarang...", flush=True)
            for remaining in range(REFRESH_SECS, 0, -1):
                if manual.is_set():
                    break
                time.sleep(1)
    except KeyboardInterrupt:
        print("\n  Keluar.\n")
