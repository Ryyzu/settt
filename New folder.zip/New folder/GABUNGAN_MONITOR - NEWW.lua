--[[
    ======================================================
       GABUNGAN: LUCIFER SENDER v10.40 + MONITOR v2.32
    ======================================================
    - SERVER_URL sinkron dengan config asli (port 7070)
    - sleep(100) aman dari C-call yield boundary di Lua 5.1
    - Bebas blind spot: cek GT langsung di run pertama
    - Timing akurat real-time menggunakan os.time()
    - Jeda reconnect 3 detik per bot
    ======================================================
]]

-- =====================================================
-- KONFIGURASI SENDER (send monitor.lua)
-- =====================================================
local SERVER_IP   = "47.77.236.88"
local SERVER_PORT = "8080"
local VPS_NAME    = "8RDP33"

-- =====================================================
-- KONFIGURASI SC MONITOR ONLINE (SC MONITOR ONLINE.lua)
-- =====================================================
-- URL Python server (server_online.py). Isi IP RDP utama.
-- Jika tidak pakai Python server, kosongkan -> langsung hit GT API
local SERVER_URL       = "https://gt.arisbibrik08.workers.dev/"

-- Ambang batas DANGER: jika online >= nilai ini -> semua bot disconnect
local THRESHOLD_DANGER = 69900

-- Ambang batas SAFE: bot baru reconnect jika online turun <= nilai ini
-- (Buffer zone antara THRESHOLD_SAFE dan THRESHOLD_DANGER mencegah flapping)
local THRESHOLD_SAFE   = 68000

-- Discord Webhook (kosong = nonaktif)
local WEBHOOK_URL      = "https://discordapp.com/api/webhooks/1059341740605177907/dwKhXl7tX4JrCpyXKiq5M0FfDbfQ5QKXYcVOUmScXPHpO_9HR7DSaX8XYizkZZkxOP7n"

-- =====================================================
-- INTERVAL
-- =====================================================
local SEND_INTERVAL    = 7        -- detik (sender + poll command)
local MONITOR_INTERVAL = 30       -- detik (monitor online GT)

-- =====================================================
-- DATA INTERNAL
-- =====================================================
local lastKnownPk  = {}  -- cache pickaxe state per bot
local manualDC     = {}  -- set bot yang di-disconnect manual via dashboard (skip auto-reconnect)

local rotMap = {
    [0] = "Scanning",   [1] = "Harvesting", [2] = "Farming",    [3] = "Planting",
    [4] = "Dropping",   [5] = "Dropping",   [6] = "Filling",    [7] = "Harvesting",
    [8] = "Collecting", [9] = "Clearing",   [10] = "Toxic",     [11] = "Object"
}

local statusMap = {
    [0]  = "Offline",             [1]  = "Online",              [2]  = "Wrong Password",
    [3]  = "Account Banned",      [4]  = "Account Suspended",   [5]  = "Location Banned",
    [6]  = "Version Update",      [7]  = "Advanced Protection", [8]  = "Server Overload",
    [9]  = "Too Many Logins",     [10] = "Maintenance",         [11] = "Server Busy",
    [12] = "Guest Limit",         [13] = "HTTP Blocked",        [14] = "Bad Name Length",
    [15] = "Invalid Account",     [16] = "Ubi Disabled",        [17] = "Account Restricted",
    [18] = "Network Restricted",  [19] = "Error Connecting",    [20] = "Logon Fail",
    [21] = "Captcha Requested",   [22] = "Mod Entered",         [23] = "Player Entered",
    [24] = "High Load",           [25] = "High Ping",           [26] = "Changing Subserver",
    [27] = "Stopped",             [28] = "Getting Server Data", [29] = "Bypassing Server Data",
    [30] = "Could Not Warp",      [31] = "Bad Inventory",       [32] = "Bad Gateway",
    [33] = "Server Issue",        [34] = "Retrieving Token",    [35] = "Two Factor",
    [36] = "Google Logon Fail",   [37] = "IDK",                 [38] = "Steam Logon Fail",
    [39] = "Linking Steam",       [40] = "Steam Not Linked",    [41] = "Solving Captcha",
    [42] = "Failed Captcha",      [43] = "Banwave Detected",    [44] = "SMS Error"
}

-- =====================================================
-- UTILS BERSAMA
-- =====================================================

local function detectBots()
    local bots = {}
    if getBots then
        local ok, result = pcall(getBots)
        if ok and result then
            for _, b in pairs(result) do
                if b then table.insert(bots, b) end
            end
        end
    end
    if #bots == 0 then
        local ok, res = pcall(getBot)
        if ok and res then
            if type(res) == "table" and res.name == nil then
                for _, b in pairs(res) do
                    if b then table.insert(bots, b) end
                end
            elseif res.name then
                table.insert(bots, res)
            end
        end
    end
    return bots
end

local function log(msg)
    local text = "[Monitor] " .. tostring(msg)
    print(text)
    local ok, bots = pcall(getBots)
    if ok and bots then
        for _, b in pairs(bots) do
            pcall(function()
                if b and b:getLog() then b:getLog():append(text) end
            end)
        end
    end
end

local function jsonGetString(body, key)
    if not body then return nil end
    -- Mendukung format angka dengan petik ("65000") maupun tanpa petik (65000)
    return body:match('"' .. key .. '"%s*:%s*"?([%d]+)"?') or body:match('"' .. key .. '"%s*:%s*"([^"]*)"')
end

local function cleanName(name)
    return tostring(name):gsub('[^%w%s]', "")
end

-- =====================================================
-- FUNGSI SENDER (send monitor.lua)
-- =====================================================

local function send()
    local bots = detectBots()
    local bList = {}
    local totalGems, onlineCount = 0, 0

    for _, b in ipairs(bots) do
        local statusNum = b.status or 0
        local isOn = (statusNum == 1)

        local gems = 0
        pcall(function() gems = math.floor(b.gem_count or 0) end)
        totalGems = totalGems + gems

        local world, activity = "N/A", "Offline"
        local pickaxeWorn = 0

        -- Cek pickaxe, pakai lastKnownPk sebagai fallback saat offline
        local pkRead = false
        pcall(function()
            local inv = b:getInventory()
            if inv then
                local pkItem = inv:getItem(98)
                if pkItem ~= nil then
                    pickaxeWorn = pkItem.isActive and 1 or 0
                    lastKnownPk[b.name] = pickaxeWorn
                    pkRead = true
                end
            end
        end)
        if not pkRead and lastKnownPk[b.name] ~= nil then
            pickaxeWorn = lastKnownPk[b.name]
        end

        if isOn then
            onlineCount = onlineCount + 1
            pcall(function()
                if b:isInWorld() then world = b:getWorld().name end
            end)
            pcall(function()
                local rot = b.rotation
                local ping = b:getPing() or 0
                activity = (rot and rotMap[rot.status] or "Active") .. " (" .. ping .. "ms)"
            end)
        else
            activity = statusMap[statusNum] or ("Unknown (" .. statusNum .. ")")
        end

        table.insert(bList, string.format(
            '{"n":"%s","s":%d,"g":%d,"w":"%s","l":"%s","pk":%d}',
            cleanName(b.name), statusNum, gems, world, activity, pickaxeWorn
        ))
    end

    local payload = string.format(
        '{"vps":"%s","total":%d,"online":%d,"gems":%d,"bots":[%s]}',
        VPS_NAME, #bots, onlineCount, totalGems, table.concat(bList, ",")
    )

    pcall(function()
        local c = HttpClient.new()
        c.url = "http://" .. SERVER_IP .. ":" .. SERVER_PORT .. "/api/receive"
        c.method = Method.post
        c.content = payload
        c.headers["Content-Type"] = "application/json"
        c:request()
    end)
end

-- =====================================================
-- HANDLER COMMAND DISCONNECT / CONNECT DENGAN URUTAN AMAN
-- =====================================================
-- Disconnect handling dilakukan inline di pollCommands

local function handleSafeConnect(b)
    if not b then return end
    local botName = cleanName(b.name)
    pcall(function()
        -- Aktifkan rotation & auto_reconnect (tanpa action connect langsung)
        if b.rotation then
            b.rotation.enabled = true
        end
        b.auto_reconnect = true
        log(string.format("[%s] [CMD:CONN] Rotation ON & Auto-reconnect ON (menunggu auto-login).", botName))
    end)
end

local function pollCommands()
    local bots = detectBots()
    for _, b in ipairs(bots) do
        local botName = cleanName(b.name)

        -- Ambil command dari server
        local cmd = nil
        local ok, err = pcall(function()
            local c = HttpClient.new()
            c.url = "http://" .. SERVER_IP .. ":" .. SERVER_PORT .. "/api/command/" .. botName
            c.method = Method.get
            c.headers["X-VPS-Name"] = VPS_NAME
            local result = c:request()
            if result then
                if result.status == 200 and result.body and result.body ~= "" then
                    cmd = result.body:match('"cmd":"([^"]+)"')
                    log(string.format("[%s] [POLL] Got cmd: %s", botName, tostring(cmd)))
                end
            else
                log(string.format("[%s] [POLL-ERR] result nil", botName))
            end
        end)
        if not ok then
            log(string.format("[%s] [POLL-ERR] %s", botName, tostring(err)))
        end

        -- Eksekusi command DI LUAR pcall (runThread tidak boleh di dalam pcall)
        if cmd == "leave" then
            pcall(function() b:leaveWorld() end)
        elseif cmd == "connect" then
            manualDC[botName] = nil  -- hapus flag manual, monitor boleh reconnect lagi
            pcall(function() handleSafeConnect(b) end)
        elseif cmd == "disconnect" then
            -- Inline disconnect + tandai manual agar monitor tidak auto-reconnect
            manualDC[botName] = true
            log(string.format("[%s] [CMD:DC] Memulai disconnect (manual flag ON)...", botName))
            pcall(function() if b.rotation then b.rotation.enabled = false end end)
            pcall(function() b.auto_reconnect = false end)
            pcall(function() b:disconnect() end)
            log(string.format("[%s] [CMD:DC] Selesai! Rotation OFF + Reconnect OFF + DC.", botName))
        elseif cmd == "wear_pickaxe" then
            pcall(function() b:wear(98) end)
        elseif cmd == "unwear_pickaxe" then
            pcall(function() b:unwear(98) end)
        end
    end
end

-- =====================================================
-- FUNGSI SC MONITOR ONLINE (SC MONITOR ONLINE.lua)
-- =====================================================

local function fetchFromServer()
    if SERVER_URL == "" then return nil end
    local ok, result = pcall(function()
        local c = HttpClient.new()
        c.url = SERVER_URL .. "/online"
        c.headers["User-Agent"] = "LuciferBot/2.32"
        return c:request()
    end)
    if not ok or not result or result.status ~= 200 then return nil end
    local online = jsonGetString(result.body, "online_user")
    return online and tonumber(online) or nil
end

local function fetchFromGT()
    local ok, result = pcall(function()
        local c = HttpClient.new()
        c.url = "https://growtopiagame.com/detail"
        c.headers["User-Agent"] = "Mozilla/5.0 LuciferBot/2.32"
        return c:request()
    end)
    if not ok or not result or result.status ~= 200 then return nil end
    local online = jsonGetString(result.body, "online_user")
    return online and tonumber(online) or nil
end

local function getOnlineCount()
    local count = fetchFromServer()
    if count then return count, "PythonServer" end
    count = fetchFromGT()
    if count then return count, "GT-API" end
    return nil, "error"
end

local function disconnectAllBots()
    local bots = detectBots()
    local total = 0
    for _, b in pairs(bots) do
        if b then
            pcall(function()
                b.auto_reconnect = false
                b:disconnect()
            end)
            total = total + 1
            sleep(100) -- sleep di luar pcall agar aman di semua runtime Lua
        end
    end
    return total
end

local function enableReconnectAllBots()
    local bots = detectBots()
    local total = 0
    for _, b in pairs(bots) do
        if b then
            local bName = cleanName(b.name)
            -- Skip bot yang di-disconnect manual via dashboard
            if manualDC[bName] then
                log(string.format("[%s] [MONITOR] Skip reconnect (manual DC flag aktif)", bName))
            else
                pcall(function()
                    b.auto_reconnect = true
                end)
                total = total + 1
                sleep(3000) -- jeda 3 detik antar bot agar tidak login serentak
            end
        end
    end
    return total
end

local function sendWebhook(title, desc, color)
    if WEBHOOK_URL == "" then return end
    pcall(function()
        local wh = Webhook.new(WEBHOOK_URL)
        wh.username = "GT Monitor"
        wh.embed1.use         = true
        wh.embed1.color       = color or 0x00C8FF
        wh.embed1.title       = title
        wh.embed1.description = desc
        wh.embed1.footer.text = os.date("%Y-%m-%d %H:%M:%S")
        wh:send()
    end)
end

local function runMonitorOnline(counter, lastState)
    local online, source = getOnlineCount()

    if not online then
        log(string.format("[Monitor#%d] [FAIL] Gagal fetch data. Skip...", counter))
        return lastState
    end

    local bots     = detectBots()
    local botCount = #bots

    -- Hysteresis logic
    local isDanger
    if lastState == "danger" then
        isDanger = (online > THRESHOLD_SAFE)
    else
        isDanger = (online >= THRESHOLD_DANGER)
    end
    local currentState = isDanger and "danger" or "safe"

    if isDanger then
        log(string.format("[Monitor#%d] [DANGER] BAHAYA! Online: %d (danger>=%d | safe<=%d) via %s",
            counter, online, THRESHOLD_DANGER, THRESHOLD_SAFE, source))

        if lastState ~= "danger" then
            log(string.format("  [!] Mematikan auto_reconnect + disconnect SEMUA %d bot...", botCount))
            local disconnected = disconnectAllBots()
            log(string.format("  [OK] %d bot berhasil di-disconnect!", disconnected))

            sendWebhook(
                "HIGH TRAFFIC - Bot Disconnected",
                string.format(
                    "Player online: **%d**\n"..
                    "Danger threshold: **%d** | Safe threshold: **%d**\n"..
                    "Bot di-disconnect: **%d**\n"..
                    "Auto reconnect: **MATI**\n"..
                    "Source: `%s`",
                    online, THRESHOLD_DANGER, THRESHOLD_SAFE, disconnected, source
                ),
                0xFF4444
            )
        else
            log(string.format("  [*] Masih bahaya. Bots tetap offline. (%d bots)", botCount))
        end
    else
        local inBuffer = (online > THRESHOLD_SAFE and online < THRESHOLD_DANGER)
        if inBuffer then
            log(string.format("[Monitor#%d] [BUFFER] BUFFER ZONE. Online: %d (%d-%d). Tidak ada aksi. via %s",
                counter, online, THRESHOLD_SAFE + 1, THRESHOLD_DANGER - 1, source))
        else
            log(string.format("[Monitor#%d] [SAFE] Aman. Online: %d (<= %d) via %s",
                counter, online, THRESHOLD_SAFE, source))
        end

        if lastState ~= "safe" and not inBuffer then
            log(string.format("  [!] Menyalakan auto_reconnect untuk %d bot...", botCount))
            local enabled = enableReconnectAllBots()
            log(string.format("  [OK] auto_reconnect ON untuk %d bot!", enabled))

            sendWebhook(
                "SAFE - Auto Reconnect ON",
                string.format(
                    "Player online: **%d**\n"..
                    "Safe threshold: **<= %d**\n"..
                    "Auto reconnect dinyalakan: **%d** bot\n"..
                    "Source: `%s`",
                    online, THRESHOLD_SAFE, enabled, source
                ),
                0x44FF88
            )
        elseif not inBuffer then
            log("  [*] Situasi aman berlanjut. Terus pantau...")
        end
    end

    return currentState
end

-- =====================================================
-- MAIN LOOP
-- =====================================================

log("==============================================")
log("  GABUNGAN: SENDER v10.40 + MONITOR v2.32    ")
log("==============================================")
log(string.format("VPS          : %s", VPS_NAME))
log(string.format("Server IP    : %s:%s", SERVER_IP, SERVER_PORT))
log(string.format("Send interval: %d detik", SEND_INTERVAL))
log(string.format("Monitor int  : %d detik", MONITOR_INTERVAL))
log(string.format("Server URL   : %s", SERVER_URL ~= "" and SERVER_URL or "GT API (direct)"))
log(string.format("Danger zone  : >= %d players -> DISCONNECT", THRESHOLD_DANGER))
log(string.format("Safe zone    : <= %d players -> RECONNECT", THRESHOLD_SAFE))
log(string.format("Buffer zone  : %d - %d (tidak ada aksi)", THRESHOLD_SAFE + 1, THRESHOLD_DANGER - 1))
log(string.format("Webhook      : %s", WEBHOOK_URL ~= "" and "Aktif" or "Nonaktif"))
log(string.format("Total bots   : %d", #detectBots()))
log("----------------------------------------------")

local lastState       = nil
local monitorCounter  = 0
-- Di-set 0 agar saat pertama kali script dijalankan, monitor langsung mengecek status online GT
local lastMonitorAt   = 0

while true do
    -- === 1. SENDER & COMMAND POLLING (setiap 7 detik) ===
    pcall(send)
    pollCommands()  -- runThread di dalam pollCommands, TIDAK boleh dibungkus pcall

    -- === 2. MONITOR ONLINE PLAYER GT (setiap 30 detik) ===
    local now = os.time()
    if (now - lastMonitorAt) >= MONITOR_INTERVAL then
        monitorCounter = monitorCounter + 1
        lastMonitorAt  = now

        local ok, newState = pcall(runMonitorOnline, monitorCounter, lastState)
        if ok and newState ~= nil then
            lastState = newState
        else
            log(string.format("[Monitor#%d] [WARN] Error saat monitor online, state dipertahankan.", monitorCounter))
        end
    end

    sleep(SEND_INTERVAL * 1000)  -- jeda 7 detik
end

