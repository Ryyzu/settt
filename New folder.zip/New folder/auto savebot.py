import subprocess
import sys
# Cek dan install requests kalau belum ada
try:
    import requests
except ImportError:
    print("Module 'requests' belum terinstall. Menginstall sekarang...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "requests"])
    import requests
import time
import hashlib
from datetime import datetime, timezone, timedelta

# === KONFIGURASI ===
WEBHOOK_URL = "https://discord.com/api/webhooks/1068473199957921862/yuq2hD7FELo-XZ2CBFxRgG1JigqTkIJ3PIUwNnysXLqVoke3GKA-HbmlisnF0oJk9bc2"
STARTUP_FILE = r"C:\Users\Administrator\Desktop\startup.json"
LOGIN_FILE = r"C:\Users\Administrator\Desktop\login.json"
CHECK_INTERVAL = 1800  # detik
CUSTOM_MESSAGE = "8RDP33"  # teks bebas

last_hash = None

def get_file_hash(file_path):
    """Hitung hash file supaya bisa cek perubahan"""
    try:
        with open(file_path, "rb") as f:
            return hashlib.md5(f.read()).hexdigest()
    except FileNotFoundError:
        return None

def send_files_to_webhook():
    """Kirim startup.json dan login.json ke Discord"""
    wib = timezone(timedelta(hours=7))
    now = datetime.now(wib).strftime("%d-%m-%Y %H:%M:%S WIB")
    
    try:
        files_to_send = []
        
        # Siapkan startup.json
        try:
            with open(STARTUP_FILE, "rb") as f:
                files_to_send.append(("file", (STARTUP_FILE.split("\\")[-1], f.read())))
        except FileNotFoundError:
            print(f"[WARNING] File {STARTUP_FILE} tidak ditemukan")
        
        # Siapkan login.json
        try:
            with open(LOGIN_FILE, "rb") as f:
                files_to_send.append(("file", (LOGIN_FILE.split("\\")[-1], f.read())))
        except FileNotFoundError:
            print(f"[WARNING] File {LOGIN_FILE} tidak ditemukan")
        
        if files_to_send:
            payload = {
                "username": "RDP File Monitor",
                "content": f"{CUSTOM_MESSAGE}\n📅 Terakhir update: **{now}**\n📁 File terkirim: **{len(files_to_send)}**"
            }
            
            # Reset file objects untuk dikirim
            files_dict = {}
            for i, (key, (filename, content)) in enumerate(files_to_send):
                files_dict[f"file{i}"] = (filename, content)
            
            requests.post(WEBHOOK_URL, data=payload, files=files_dict, timeout=15)
            print(f"[INFO] {len(files_to_send)} file terkirim ke Discord {now}")
        else:
            print("[ERROR] Tidak ada file yang bisa dikirim")
            
    except Exception as e:
        print(f"[ERROR] Gagal kirim file: {e}")

print(f"[INFO] Script dimulai - Monitoring {STARTUP_FILE}")
print(f"[INFO] Interval check: {CHECK_INTERVAL} detik ({CHECK_INTERVAL//60} menit)")

while True:
    new_hash = get_file_hash(STARTUP_FILE)
    
    if new_hash and new_hash != last_hash:
        print(f"[INFO] Perubahan terdeteksi pada {STARTUP_FILE}")
        send_files_to_webhook()
        last_hash = new_hash
    
    time.sleep(CHECK_INTERVAL)
