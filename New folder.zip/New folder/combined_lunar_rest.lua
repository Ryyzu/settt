-- ============================================================
--   LUNAR EVENT + AUTO REST CYCLE (Combined)
--   Items: Chinese Arch [5746] -> Paper Dividing Wall [5742] -> Coin Door [5748]
--   Bot diam di (44,17), break 5 tile ke kanan
-- ============================================================

-- ==================== CONFIG LUNAR ====================
local SAVE_WORLD = "LUPING123|009"  -- Nama save world kamu

-- Block IDs
local CHINESE_ARCH_ID  = 5746
local PAPER_WALL_ID    = 5742
local COIN_DOOR_ID     = 5748

-- Seed IDs (block ID + 1 atau lookup nama)
local CHINESE_ARCH_SEED  = 5747
local PAPER_WALL_SEED    = 5743
local COIN_DOOR_SEED     = 5749

local TRIGGER_COUNT = 150    -- Jumlah item untuk trigger
local BOT_X = 44            -- Posisi bot X
local BOT_Y = 17            -- Posisi bot Y

-- 5 tile target place & break (posisi bot di 44,17)
local SIDE_TILES = {
    {42, 16},
    {43, 16},
    {44, 16},
    {45, 16},
    {46, 16},
}

-- Settings Delays
local CHECK_INTERVAL = 3000  -- ms cek inventory/status
local PLACE_DELAY    = 155   -- ms antar place
local HIT_DELAY      = 195   -- ms antar hit
local COLLECT_DELAY  = 500  -- ms sebelum collect
local WARP_DELAY     = 12000 -- ms tunggu setelah warp
local DROP_DELAY     = 2000   -- ms antar drop

-- ==================== CONFIG REST ====================
-- Konfigurasi Random (dalam menit)
local ONLINE_MIN  = 40
local ONLINE_MAX  = 43
local OFFLINE_MIN = 6
local OFFLINE_MAX = 8
-- =====================================================

local bot = getBot()
local is_processing_lunar = false
local cycle_start_time = os.time()
local online_duration_sec = 0
local is_resting = false
local last_lunar_failure_time = 0 -- Cooldown jika gagal lunar
local origin_farm_world = ""    -- Mencatat world farm terakhir agar tidak salah break

-- -------------------------------------------------------
-- Helper: log ke console
-- -------------------------------------------------------
local function log(tag, msg)
    bot:getConsole():append("`6[" .. tag .. "] `$" .. msg)
    print("[" .. tag .. "] " .. msg)
end

-- -------------------------------------------------------
-- Helper: online timer/randomizer
-- -------------------------------------------------------
local function getRandomOnlineDuration()
    return math.random(ONLINE_MIN * 60, ONLINE_MAX * 60)
end

local function getRandomOfflineDuration()
    return math.random(OFFLINE_MIN * 60, OFFLINE_MAX * 60)
end

-- Init durasi online pertama
online_duration_sec = getRandomOnlineDuration()
log("Rest", string.format("Bot akan online selama %d menit %d detik", math.floor(online_duration_sec/60), online_duration_sec%60))

-- -------------------------------------------------------
-- Lunar Functions
-- -------------------------------------------------------
local function getCurrentWorldName()
    local world = bot:getWorld()
    if world then
        local name = tostring(world.name or "")
        -- "EXIT" biasanya berarti bot sedang proses warp keluar
        if name:upper() == "EXIT" then return "" end
        return name
    end
    return ""
end

local function goHome()
    local initialWorld = origin_farm_world
    log("Lunar", "Mencoba pulang ke home via /home...")
    
    local attempt = 1
    while true do
        bot:say("/home")
        -- Tunggu bot proses warp keluar
        sleep(WARP_DELAY)
        
        local currentWorld = getCurrentWorldName()
        
        -- Jika world berubah dan bukan world asal
        if currentWorld ~= "" and string.upper(currentWorld) ~= string.upper(initialWorld) then
            -- Tetap cek perisai keamanan (jangan sampai itu world farm lain)
            if currentWorld:find("|") then
                log("Lunar", "`4Salah lari ke world farm (" .. currentWorld .. "). Mencoba /home lagi...")
            else
                log("Lunar", "`2Berhasil masuk home: " .. currentWorld)
                return true
            end
        end
        
        -- Gagal warp
        log("Lunar", string.format("`4Gagal ke home (Percobaan %d). Menunggu 14 detik...", attempt))
        sleep(14000)
        attempt = attempt + 1
    end
end

local function moveToTile(x, y)
    if bot:isInTile(x, y) then return true end
    bot:findPath(x, y)
    local tries = 0
    while not bot:isInTile(x, y) and tries < 60 do
        sleep(300)
        tries = tries + 1
    end
    return bot:isInTile(x, y)
end

local function goSaveWorld()
    log("Lunar", "Warp ke save world: " .. SAVE_WORLD)
    bot:warp(SAVE_WORLD)
    sleep(WARP_DELAY)
    local tries = 0
    while not bot:isInWorld(SAVE_WORLD) and tries < 20 do
        sleep(500)
        tries = tries + 1
    end
    return bot:isInWorld(SAVE_WORLD)
end

local function runBatch(itemId, qty)
    local placed = {}
    local count = math.min(qty, 5)

    -- Phase 1: Clear & Place
    for i = 1, count do
        local tx = SIDE_TILES[i][1]
        local ty = SIDE_TILES[i][2]
        local tile = getTile(tx, ty)
        
        -- Jika tile terisi blok lain (bukan target), bersihkan dulu
        if tile.fg ~= 0 and tile.fg ~= itemId then
            log("Lunar", string.format("Tile (%d,%d) terhalang ID %d. Membersihkan...", tx, ty, tile.fg))
            local clearAttempts = 0
            while getTile(tx, ty).fg ~= 0 and getTile(tx, ty).fg ~= itemId and clearAttempts < 20 do
                bot:hit(tx, ty)
                sleep(HIT_DELAY)
                clearAttempts = clearAttempts + 1
            end
        end

        tile = getTile(tx, ty)
        if tile.fg == itemId then
            table.insert(placed, {tx, ty})
        elseif tile.fg == 0 then
            bot:place(tx, ty, itemId)
            
            -- Tunggu sampai blok beneran muncul (tahan lag)
            local checkTries = 0
            while getTile(tx, ty).fg ~= itemId and checkTries < 4 do
                sleep(PLACE_DELAY + (checkTries * 30))
                checkTries = checkTries + 1
            end
            
            if getTile(tx, ty).fg == itemId then
                table.insert(placed, {tx, ty})
            end
        end
    end

    if #placed == 0 then return 0 end

    -- Phase 2: Hit until broken
    for _, pos in ipairs(placed) do
        local px, py = pos[1], pos[2]
        local attempts = 0
        while getTile(px, py).fg ~= 0 and attempts < 50 do
            bot:hit(px, py)
            sleep(HIT_DELAY + 25)
            attempts = attempts + 1
        end
    end

    -- Phase 3: Cleanup (double check)
    for i = 1, count do
        local tx, ty = SIDE_TILES[i][1], SIDE_TILES[i][2]
        local lastCheck = 0
        while getTile(tx, ty).fg ~= 0 and lastCheck < 10 do
            bot:hit(tx, ty)
            sleep(HIT_DELAY + 50)
            lastCheck = lastCheck + 1
        end
    end

    -- Phase 4: Collect
    sleep(COLLECT_DELAY)
    bot:collect(8) -- Ambil semua (jangan batasi count jika tidak yakin)
    sleep(200)

    return #placed
end

local function breakAllItem(itemId)
    local name = getInfo(itemId).name or itemId
    log("Lunar", string.format("Processing %s until clean...", name))
    
    local failCount = 0
    while bot:getInventory():findItem(itemId) > 0 do
        if not bot:isInTile(BOT_X, BOT_Y) then
            moveToTile(BOT_X, BOT_Y)
        end

        local done = runBatch(itemId, 5)
        
        if done > 0 then
            failCount = 0
        else
            -- Jika ada item tapi tidak bisa diproses, kemungkinan tile macet/lag
            log("Lunar", "`4Macet? Mencoba membersihkan area...")
            for i = 1, #SIDE_TILES do
                local tx, ty = SIDE_TILES[i][1], SIDE_TILES[i][2]
                if getTile(tx, ty).fg ~= 0 then bot:hit(tx, ty) sleep(HIT_DELAY) end
            end
            bot:collect(8)
            
            failCount = failCount + 1
            if failCount >= 12 then 
                log("Lunar", "`4Gagal membersihkan " .. name .. " setelah beberapa kali coba.")
                break 
            end
            sleep(2000)
        end
        sleep(100)
    end

    -- Final sweep biar beneran 'bersih'
    log("Lunar", "Final sweep for " .. name)
    for i = 1, #SIDE_TILES do
        local tx, ty = SIDE_TILES[i][1], SIDE_TILES[i][2]
        while getTile(tx, ty).fg ~= 0 do
            bot:hit(tx, ty)
            sleep(HIT_DELAY + 50)
        end
    end
    bot:collect(8)
end

local function findSeedIdDirectly(blockId)
    local info = getInfo(blockId)
    if info then
        local seedName = info.name .. " Seed"
        local seedInfo = getInfo(seedName)
        if seedInfo then return seedInfo.id end
    end
    return blockId + 1
end

local function processLunarItems()
    -- JITTER: Antrian acak agar tidak tabrakan /home dengan bot lain (1-10 detik)
    local jitter = math.random(1000, 10000)
    log("Lunar", string.format("Tas penuh! Mengantre selama %.1f detik agar tidak clash...", jitter/1000))
    sleep(jitter)

    origin_farm_world = getCurrentWorldName()
    if origin_farm_world == "" then
        log("Lunar", "Menunggu world stabil sebelum mencatat origin...")
        sleep(3000)
        origin_farm_world = getCurrentWorldName()
    end

    is_processing_lunar = true
    local inv = bot:getInventory()
    local archCount = inv:findItem(CHINESE_ARCH_ID)
    local wallCount = inv:findItem(PAPER_WALL_ID)
    local coinCount = inv:findItem(COIN_DOOR_ID)

    log("Lunar", "TRIGGER! Mematikan rotation...")
    bot.rotation.enabled = false
    bot.auto_collect = false 
    sleep(800)

    -- Bot akan mencoba pulang terus sampai berhasil
    goHome()

    -- Cek sekali lagi: Jangan sampai break di world farm asal!
    local current = getCurrentWorldName()
    if current == "" or string.upper(current) == string.upper(origin_farm_world) or current:find("|") then
        log("Lunar", "`4BATAL: Deteksi world tidak aman! Menunggu 14 detik.")
        sleep(14000) 
        bot.rotation.enabled = true
        is_processing_lunar = false
        last_lunar_failure_time = os.time()
        return
    end

    if not moveToTile(BOT_X, BOT_Y) then
        log("Lunar", "`4Gagal mencapai tile target (44,17). Mencoba lanjut...")
    end

    if bot:getInventory():findItem(CHINESE_ARCH_ID) > 0 then 
        breakAllItem(CHINESE_ARCH_ID) 
    end
    
    if bot:getInventory():findItem(PAPER_WALL_ID) > 0 then 
        breakAllItem(PAPER_WALL_ID) 
    end

    if bot:getInventory():findItem(COIN_DOOR_ID) > 0 then 
        breakAllItem(COIN_DOOR_ID) 
    end

    local warpOk = false
    log("Lunar", "Warp ke world penyimpanan...")
    for attempt = 1, 3 do
        if goSaveWorld() then warpOk = true break end
        sleep(6000)
    end

    if warpOk then
        sleep(2000)
        local seed1 = findSeedIdDirectly(CHINESE_ARCH_ID)
        local seed2 = findSeedIdDirectly(PAPER_WALL_ID)
        local seed3 = findSeedIdDirectly(COIN_DOOR_ID)

        bot:moveRight(5)
        sleep(1000)

        local function smartDrop(id)
            local count = bot:getInventory():findItem(id)
            if count <= 0 then return end
            
            local name = getInfo(id).name or id
            local dropTries = 0
            while bot:getInventory():findItem(id) > 0 and dropTries < 5 do
                bot:drop(id, count)
                sleep(2000)
                
                if bot:getInventory():findItem(id) > 0 then
                    bot:moveRight(2)
                    sleep(1000)
                    dropTries = dropTries + 1
                    count = bot:getInventory():findItem(id)
                end
            end
        end

        smartDrop(seed1)
        smartDrop(seed2)
        smartDrop(seed3)
        -- Jangan drop block di save world (agar bersih)
        -- smartDrop(CHINESE_ARCH_ID)
        -- smartDrop(PAPER_WALL_ID)
    end

    bot.rotation.enabled = true
    is_processing_lunar = false
end

-- -------------------------------------------------------
-- MAIN LOOP (Combined)
-- -------------------------------------------------------
log("System", "Combined Script Lunar + Rest Started")

while true do
    local current_time = os.time()
    local elapsed = os.difftime(current_time, cycle_start_time)

    -- 1. Check for REST CYCLE
    if not is_resting and elapsed >= online_duration_sec and not is_processing_lunar then
        is_resting = true
        log("Rest", "======= REST PHASE STARTED =======")
        bot.rotation.enabled = false
        bot.auto_reconnect = false
        log("Rest", "Disconnecting...")
        bot:disconnect()

        local rest_duration = getRandomOfflineDuration()
        log("Rest", string.format("Resting for: %d min %d sec", math.floor(rest_duration/60), rest_duration%60))
        
        sleep(rest_duration * 1000)

        log("Rest", "Rest complete! Reconnecting...")
        bot.auto_reconnect = true
        
        -- Tunggu sampai benar-benar online atau timeout 60 detik
        local reconnect_start = os.time()
        while bot.status ~= BotStatus.online do
            if os.difftime(os.time(), reconnect_start) > 60 then
                log("Rest", "`4Gagal reconnect dalam 60 detik. Mencoba lanjut...")
                break
            end
            sleep(1000)
        end
        
        if bot.status == BotStatus.online then
            log("Rest", "`2Bot sudah online kembali.")
        end
        
        -- Reset Online Timer
        cycle_start_time = os.time()
        online_duration_sec = getRandomOnlineDuration()
        is_resting = false
        bot.rotation.enabled = true
        log("Rest", string.format("New Online Phase: %d min", math.floor(online_duration_sec/60)))
    end

    -- 2. Check for LUNAR TRIGGER (Hanya jika tidak sedang istirahat & sudah lewat delay 14 detik)
    if not is_resting and not is_processing_lunar and os.difftime(os.time(), last_lunar_failure_time) > 14 then
        local inv = bot:getInventory()
        local archCount = inv:findItem(CHINESE_ARCH_ID)
        local wallCount = inv:findItem(PAPER_WALL_ID)
        local coinCount = inv:findItem(COIN_DOOR_ID)

        if archCount >= TRIGGER_COUNT or wallCount >= TRIGGER_COUNT or coinCount >= TRIGGER_COUNT then
            processLunarItems()
        end
    end

    sleep(CHECK_INTERVAL)
end
