--[[
    LUCIFER SENDER v10.40 (Pro Status Mapping)
    ==========================================
    - Fix: Complete 44-Status Real Mapping
    - Sync: Precise status text from official list
    - Performance: Optimized bot scanning
]]

local SERVER_IP = "47.77.236.88" 
local SERVER_PORT = "8080"
local VPS_NAME = "8RDP20" 

-- Cache pk state per bot (persist across offline periods)
local lastKnownPk = {}

local rotMap = {
    [0] = "Scanning", [1] = "Harvesting", [2] = "Farming", [3] = "Planting", 
    [4] = "Dropping", [5] = "Dropping", [6] = "Filling", [7] = "Harvesting",
    [8] = "Collecting", [9] = "Clearing", [10] = "Toxic", [11] = "Object"
}

-- Comprehensive Status Mapping (v10.40)
local statusMap = {
    [0] = "Offline", [1] = "Online", [2] = "Wrong Password", [3] = "Account Banned",
    [4] = "Account Suspended", [5] = "Location Banned", [6] = "Version Update",
    [7] = "Advanced Protection", [8] = "Server Overload", [9] = "Too Many Logins",
    [10] = "Maintenance", [11] = "Server Busy", [12] = "Guest Limit",
    [13] = "HTTP Blocked", [14] = "Bad Name Length", [15] = "Invalid Account",
    [16] = "Ubi Disabled", [17] = "Account Restricted", [18] = "Network Restricted",
    [19] = "Error Connecting", [20] = "Logon Fail", [21] = "Captcha Requested",
    [22] = "Mod Entered", [23] = "Player Entered", [24] = "High Load",
    [25] = "High Ping", [26] = "Changing Subserver", [27] = "Stopped",
    [28] = "Getting Server Data", [29] = "Bypassing Server Data", [30] = "Could Not Warp",
    [31] = "Bad Inventory", [32] = "Bad Gateway", [33] = "Server Issue",
    [34] = "Retrieving Token", [35] = "Two Factor", [36] = "Google Logon Fail",
    [37] = "IDK", [38] = "Steam Logon Fail", [39] = "Linking Steam",
    [40] = "Steam Not Linked", [41] = "Solving Captcha", [42] = "Failed Captcha",
    [43] = "Banwave Detected", [44] = "SMS Error"
}

function detectBots()
    local bots = {}
    local res = getBot()
    if res and type(res) == "table" and res.name == nil then
        for _, b in pairs(res) do table.insert(bots, b) end
    elseif res and res.name then table.insert(bots, res) end
    if #bots == 0 and getBots then
        pcall(function() for _, b in pairs(getBots()) do table.insert(bots, b) end end)
    end
    return bots
end

function send()
    local bots = detectBots()
    local bList = {}
    local totalGems, onlineCount = 0, 0
    
    for i, b in ipairs(bots) do
        local statusNum = b.status or 0
        local isOn = (statusNum == 1)
        
        totalGems = totalGems + math.floor(b.gem_count or 0)
        
        local world, activity = "N/A", "Offline"
        local pickaxeWorn = 0

        -- Cek pickaxe, pakai lastKnownPk sebagai fallback saat offline
        local pkRead = false
        pcall(function()
            local inv = b:getInventory()
            if inv then
                local pkItem = inv:getItem(98)
                if pkItem ~= nil then
                    pickaxeWorn = pkItem.isActive and 1 or 0
                    lastKnownPk[b.name] = pickaxeWorn -- simpan state terakhir
                    pkRead = true
                end
            end
        end)
        -- Kalau inventory tidak bisa dibaca (offline), pakai nilai terakhir
        if not pkRead and lastKnownPk[b.name] ~= nil then
            pickaxeWorn = lastKnownPk[b.name]
        end

        if isOn then
            onlineCount = onlineCount + 1
            pcall(function() if b:isInWorld() then world = b:getWorld().name end end)
            pcall(function()
                local rot = b.rotation
                activity = (rot and rotMap[rot.status] or "Active") .. " (" .. (b:getPing() or 0) .. "ms)"
            end)
        else
            activity = statusMap[statusNum] or "Unknown ("..statusNum..")"
        end
        
        table.insert(bList, string.format('{"n":"%s","s":%d,"g":%d,"w":"%s","l":"%s","pk":%d}',
            tostring(b.name:gsub('[^%w%s]', "")), statusNum, 
            math.floor(b.gem_count or 0), world, activity, pickaxeWorn))
    end
    
    local payload = string.format('{"vps":"%s","total":%d,"online":%d,"gems":%d,"bots":[%s]}',
        VPS_NAME, #bots, onlineCount, totalGems, table.concat(bList, ","))
    
    local c = HttpClient.new()
    c.url = "http://"..SERVER_IP..":"..SERVER_PORT.."/api/receive"
    c.method = Method.post
    c.content = payload
    c.headers["Content-Type"] = "application/json"
    c:request()
end

function pollCommands()
    local bots = detectBots()
    for i, b in ipairs(bots) do
        local botName = tostring(b.name:gsub('[^%w%s]', ""))
        local c = HttpClient.new()
        c.url = "http://"..SERVER_IP..":"..SERVER_PORT.."/api/command/"..botName
        c.method = Method.get
        c.headers["X-VPS-Name"] = VPS_NAME
        pcall(function()
            local result = c:request()
            if result and result.status == 200 and result.body and result.body ~= "" then
                local cmd = result.body:match('"cmd":"([^"]+)"')
                if cmd == "leave" then
                    pcall(function() b:leaveWorld() end)
                elseif cmd == "connect" then
                    pcall(function() b:connect() end)
                elseif cmd == "disconnect" then
                    pcall(function() b:disconnect() end)
                elseif cmd == "wear_pickaxe" then
                    pcall(function() b:wear(98) end)
                elseif cmd == "unwear_pickaxe" then
                    pcall(function() b:unwear(98) end)
                end
            end
        end)
    end
end

while true do
    pcall(send)
    pcall(pollCommands)
    sleep(7000)
end
